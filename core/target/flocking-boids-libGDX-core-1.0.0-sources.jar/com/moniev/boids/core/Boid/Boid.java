package com.moniev.boids.core.Boid;

import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.moniev.boids.core.Vector.Vector;

public class Boid {
  public Vector position, lastPosition, acceleration;
  public final Model model;
  public ModelInstance modelInstance;
  private final float minVelocity, maxVelocity;

  public Boid(Vector position, Vector initialVelocity, float dt, Model model, ModelInstance modelInstance,
      float minVelocity, float maxVelocity) {
    this.position = new Vector(position);
    this.lastPosition = position.substract(initialVelocity.multiply(dt));
    this.model = model;
    this.modelInstance = modelInstance;
    this.acceleration = new Vector(0, 0, 0);
    this.minVelocity = minVelocity;
    this.maxVelocity = maxVelocity;
  }

  public void accelerate(Vector a) {
    acceleration.set(acceleration.add(a));
  }

  public void setVelocity(Vector v, float dt) {
    lastPosition.set(position.substract(v.multiply(dt)));
  }

  public void addVelocity(Vector v, float dt) {
    lastPosition.set(lastPosition.substract(v.multiply(dt)));
  }

  public Vector getVelocity(float dt) {
    return position.substract(lastPosition).subdivide(dt);
  }

  public void printBoid() {
    String sPosition = position.toString();
    String sLastPosition = lastPosition.toString();
    System.out.printf("[position: %s][last position %s]\n", sPosition, sLastPosition);
  }

  public void update(float dt) {
    Vector velocity = getVelocity(dt);
    float speed = velocity.length();

    Vector limitedVelocity = velocity;
    if (speed > maxVelocity) {
      limitedVelocity = velocity.subdivide(speed).multiply(maxVelocity);
    } else if (speed < minVelocity) {
      if (speed != 0) {
        limitedVelocity = velocity.subdivide(speed).multiply(minVelocity);
      }
    }

    setVelocity(limitedVelocity, dt);

    Vector displacement = position.substract(lastPosition);
    Vector newPosition = position.add(displacement).add(acceleration.multiply(dt * dt));

    lastPosition.set(position);
    position.set(newPosition);

    acceleration.set(0);
  }
}
